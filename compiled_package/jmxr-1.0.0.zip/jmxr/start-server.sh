#!/bin/sh
/apps/elsdev/.local/python/bin/python /apps/elsdev/JMXr/server/server.py >> /apps/elsdev/JMXr/serverlog.log