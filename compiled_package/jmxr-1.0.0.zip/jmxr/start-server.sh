#!/bin/sh
/apps/.local/python/bin/python /apps/JMXr/server/server.py >> /apps/JMXr/serverlog.log