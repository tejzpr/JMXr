#!/bin/sh
kill -9 $(cat /apps/JMXr/pid_server.txt)