#!/bin/sh
kill -9 $(cat /apps/elsdev/JMXr/pid.txt)